"""
N-panel UI for the s&box Bridge v2 addon.
Provides connect/disconnect, sync controls, grid, warnings, and material management.
"""

import bpy
import os
import time
import traceback
from . import connection
from . import sync


_section_errors_printed = set()

# Thumbnail cache for generated bridge materials (Blender preview icons).
_material_previews = None


def _material_preview_icon(image_path):
    """icon_id for an image file, cached in a bpy.utils.previews collection.
    Keyed by path+mtime so a re-copied texture refreshes its thumbnail."""
    global _material_previews
    if _material_previews is None:
        import bpy.utils.previews
        _material_previews = bpy.utils.previews.new()
    try:
        key = f"{image_path}:{os.path.getmtime(image_path)}"
    except OSError:
        return None
    if key not in _material_previews:
        _material_previews.load(key, image_path, 'IMAGE')
    return _material_previews[key].icon_id


def clear_material_previews():
    """Release the preview collection (called from addon unregister)."""
    global _material_previews
    if _material_previews is not None:
        try:
            import bpy.utils.previews
            bpy.utils.previews.remove(_material_previews)
        except Exception:
            pass
        _material_previews = None


def _draw_section_error(layout, section, exc):
    """A broken panel section must say so, not vanish. The old bare
    'except: pass' made a crashed section invisible — indistinguishable from
    'nothing to show', which is exactly how silent failures hide."""
    try:
        row = layout.row()
        row.alert = True
        row.label(text=f"{section} UI error — see console", icon="ERROR")
        key = f"{section}:{exc}"
        if key not in _section_errors_printed:
            _section_errors_printed.add(key)
            print(f"[s&box Bridge] Panel section '{section}' failed: {exc}")
            traceback.print_exc()
    except Exception:
        pass


# ── Operators ─────────────────────────────────────────────────────────────


class SBOX_OT_ClearWarnings(bpy.types.Operator):
    bl_idname = "sbox.bridge_clear_warnings"
    bl_label = "Clear Warnings"
    bl_description = "Dismiss all warnings (they remain in the activity log)"

    def execute(self, context):
        sync.clear_warnings()
        return {"FINISHED"}

class SBOX_OT_Connect(bpy.types.Operator):
    bl_idname = "sbox.bridge_connect"
    bl_label = "Connect"
    bl_description = "Connect to the s&box bridge server"

    def execute(self, context):
        settings = context.scene.sbox_bridge
        success, session_id = connection.connect(
            host=settings.host,
            port=settings.port,
        )
        if success:
            settings.is_connected = True
            sync.start_timer()
            # Auto-detect Assets folder. Server walks up from the active scene's
            # resource path to find the project's Assets folder. Only writes the
            # setting if the user hasn't already set one — manual override wins.
            try:
                resp = connection.send_and_receive({"type": "get_project_info"})
                if resp and resp.get("assetsDir"):
                    server_path = resp["assetsDir"]
                    if not settings.project_assets_path:
                        settings.project_assets_path = server_path
                        sync.log_activity(f"Auto-detected Assets path: {server_path}")
                    elif bpy.path.abspath(settings.project_assets_path).rstrip("\\/") != server_path.rstrip("\\/"):
                        sync.log_activity(
                            f"Server suggests Assets path: {server_path} "
                            f"(keeping user-set: {settings.project_assets_path})"
                        )
                elif resp:
                    diag = resp.get("diag") or {}
                    # Print full diagnostic so we can see exactly where discovery failed.
                    print(f"[s&box Bridge] Auto-detect failed. Server diag: {diag}")
                    if diag.get("discoveryError"):
                        sync.log_activity(f"Auto-detect error: {diag['discoveryError']}")
                    elif diag.get("sessionState") != "active":
                        sync.log_activity(f"Auto-detect: no active editor session (state={diag.get('sessionState')})")
                    elif diag.get("sceneState") != "active":
                        sync.log_activity("Auto-detect: editor session has no active scene")
                    elif not diag.get("sceneResourcePath"):
                        sync.log_activity("Auto-detect: scene has no resource path (unsaved?)")
                    elif not diag.get("fullScenePath"):
                        sync.log_activity(f"Auto-detect: scene path '{diag.get('sceneResourcePath')}' didn't resolve")
                    else:
                        sync.log_activity(
                            f"Auto-detect: walked up from {diag.get('fullScenePath')}, "
                            f"no Assets folder found (first checked: {diag.get('firstAssetsCandidate')})"
                        )
            except Exception as e:
                print(f"[s&box Bridge] get_project_info failed: {e}")
            # Do NOT auto-push untracked objects. Connecting used to
            # mass-create every untracked mesh/light engine-side — open a
            # donor kitbash file, hit Connect out of habit, and 300 source
            # pieces flooded the engine scene (even in MANUAL mode). Now we
            # only reconcile known state and REPORT what's unpushed.
            untracked = 0
            for obj in list(bpy.data.objects):
                if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                    continue
                if obj.type == "MESH" and not sync.get_bridge_id(obj):
                    untracked += 1
                elif obj.type == "LIGHT" and not sync.get_bridge_id(obj):
                    if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                        untracked += 1
            # Full sync on connect is opt-in: for large scenes the engine
            # answers with every object's full mesh data, which stalls both
            # sides. Default is connect-only; Sync All does the reconcile.
            if getattr(settings, "sync_on_connect", False):
                sync.send_sync()
            else:
                sync.log_activity(
                    "Connected — sync on connect is off, use Sync All to reconcile"
                )
            if untracked:
                sync.log_activity(
                    f"Connected — {untracked} untracked object(s), "
                    "use Sync All to push them"
                )
                self.report(
                    {"INFO"},
                    f"Connected — {untracked} untracked object(s), use Sync All to push",
                )
            else:
                self.report({"INFO"}, f"Connected to s&box at {settings.host}:{settings.port}")
        else:
            settings.is_connected = False
            self.report({"ERROR"}, f"Failed to connect to {settings.host}:{settings.port}")
        return {"FINISHED"}


class SBOX_OT_Disconnect(bpy.types.Operator):
    bl_idname = "sbox.bridge_disconnect"
    bl_label = "Disconnect"
    bl_description = "Disconnect from the s&box bridge server"

    def execute(self, context):
        connection.disconnect()
        sync.stop_timer()
        context.scene.sbox_bridge.is_connected = False
        self.report({"INFO"}, "Disconnected from s&box")
        return {"FINISHED"}


class SBOX_OT_SetGridSize(bpy.types.Operator):
    """Set bridge grid_size to a preset value. Wired to the [1, 2, 4, 8, 16, 32, 64, 128]
    button row in the panel; the property's update callback handles the rest."""
    bl_idname = "sbox.bridge_set_grid_size"
    bl_label = "Set Grid Size"
    bl_options = {'INTERNAL'}
    value: bpy.props.IntProperty(min=1, max=256)

    def execute(self, context):
        context.scene.sbox_bridge.grid_size = self.value
        return {"FINISHED"}


class SBOX_OT_HalveGrid(bpy.types.Operator):
    """Halve the bridge grid_size, clamped at 1. Bound to '[' by default."""
    bl_idname = "sbox.bridge_halve_grid"
    bl_label = "Halve Grid"

    def execute(self, context):
        s = context.scene.sbox_bridge
        s.grid_size = max(1, s.grid_size // 2)
        self.report({"INFO"}, f"Grid: {s.grid_size}")
        return {"FINISHED"}


class SBOX_OT_DoubleGrid(bpy.types.Operator):
    """Double the bridge grid_size, clamped at 256. Bound to ']' by default."""
    bl_idname = "sbox.bridge_double_grid"
    bl_label = "Double Grid"

    def execute(self, context):
        s = context.scene.sbox_bridge
        s.grid_size = min(256, s.grid_size * 2)
        self.report({"INFO"}, f"Grid: {s.grid_size}")
        return {"FINISHED"}


class SBOX_OT_SyncAll(bpy.types.Operator):
    bl_idname = "sbox.bridge_sync_all"
    bl_label = "Sync All"
    bl_description = "Send all Blender objects to s&box and request s&box objects"

    @classmethod
    def poll(cls, context):
        return connection.is_connected()

    def execute(self, context):
        created = 0
        updated = 0
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            bid = sync.get_bridge_id(obj)
            # Never resurrect objects held in Bridge Trash.
            if bid and bid in sync._inbound_pending_deletes:
                continue
            # Create when the ENGINE doesn't have it — not when the object
            # lacks an id. Objects keep their id across engine sessions now,
            # so an id the engine doesn't know must go down the create path
            # (which re-sends it under the same identity).
            engine_has = bid and bid in sync._last_known_bridge_ids
            if obj.type == "MESH":
                if not engine_has:
                    sync.send_create(obj)
                    created += 1
                else:
                    sync.send_update_mesh(obj)
                    updated += 1
            elif obj.type == "LIGHT":
                if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                    if not engine_has:
                        sync.send_create_light(obj)
                        created += 1
                    else:
                        sync.send_update_light(obj)
                        updated += 1
        sync.send_sync()
        self.report({"INFO"}, f"Synced {created + updated} objects ({created} new, {updated} updated)")
        return {"FINISHED"}


class SBOX_OT_ForceResync(bpy.types.Operator):
    bl_idname = "sbox.bridge_force_resync"
    bl_label = "Force Resync"
    bl_description = (
        "DESTRUCTIVE: deletes every bridge object on the s&box side and "
        "re-creates them from Blender. Any custom s&box-side materials "
        "(water shaders, manually-applied vmats) and any geometry edits "
        "made in s&box will be lost"
    )

    @classmethod
    def poll(cls, context):
        return connection.is_connected()

    def invoke(self, context, event):
        # Confirmation dialog. Force Resync is destructive — it deletes every
        # bridge object on the s&box side before re-creating, so any custom
        # materials or geometry authored in s&box are gone. Make the user
        # acknowledge before proceeding.
        return context.window_manager.invoke_confirm(
            self,
            event,
            message=(
                "Force Resync will DELETE every bridge object on the s&box side "
                "and re-create them from Blender.\n\n"
                "You will lose:\n"
                "  • Any custom materials applied in s&box (water shaders, "
                "manually-set vmats)\n"
                "  • Any geometry edits made in s&box on bridge objects\n\n"
                "Bridge IDs are preserved (Blender owns them; objects are "
                "re-created under the same identity).\n\n"
                "Continue?"
            ),
            title="Force Resync — destructive",
            icon='ERROR',
            confirm_text="Force Resync",
        )

    def execute(self, context):
        # Step 1: Delete all existing bridge objects from s&box
        old_ids = []
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if obj.type in ("MESH", "LIGHT"):
                bid = sync.get_bridge_id(obj)
                if bid and bid not in sync._inbound_pending_deletes:
                    old_ids.append(bid)

        for bid in old_ids:
            sync.send_delete(bid)

        # Step 2: Reset tracking. IDs stay on the objects — Blender owns
        # them and the engine honors them on re-create, so identity (and the
        # engine-side mesh caches keyed by it) survives the resync.
        sync._last_known_bridge_ids.clear()
        sync._last_scale.clear()
        sync._last_write_seq.clear()
        sync._material_hash_cache.clear()
        sync._pending_deletes.clear()

        # Step 3: Re-create everything under its existing (or fresh) ID.
        # send_create/send_create_light reuse the object's id; _last_known
        # was just cleared so nothing is skipped as already-known.
        count = 0
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if sync._should_skip_object(obj):
                continue
            bid = sync.get_bridge_id(obj)
            if bid and bid in sync._inbound_pending_deletes:
                continue
            if obj.type == "MESH":
                sync.send_create(obj)
                count += 1
            elif obj.type == "LIGHT":
                if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                    sync.send_create_light(obj)
                    count += 1

        # Don't call send_sync() — it would re-import old s&box objects as duplicates
        self.report({"INFO"}, f"Force resynced {count} objects (IDs preserved)")
        return {"FINISHED"}


class SBOX_OT_SendToScene(bpy.types.Operator):
    bl_idname = "sbox.bridge_send_to_scene"
    bl_label = "Send to Scene"
    bl_description = "Send selected objects to s&box (create new or update existing)"

    @classmethod
    def poll(cls, context):
        return connection.is_connected() and context.selected_objects

    def execute(self, context):
        created = 0
        updated = 0
        skipped = 0

        for obj in context.selected_objects:
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                skipped += 1
                continue

            if obj.type == "MESH":
                if sync.get_bridge_id(obj):
                    sync.send_update_mesh(obj)
                    updated += 1
                else:
                    sync.send_create(obj)
                    created += 1
            elif obj.type == "LIGHT":
                if obj.data and obj.data.type in sync.UNSUPPORTED_LIGHT_TYPES:
                    sync.add_warning(f"Skipped '{obj.name}': AREA lights not supported")
                    skipped += 1
                    continue
                if sync.get_bridge_id(obj):
                    sync.send_update_light(obj)
                    updated += 1
                else:
                    sync.send_create_light(obj)
                    created += 1
            else:
                skipped += 1

        parts = []
        if created:
            parts.append(f"{created} new")
        if updated:
            parts.append(f"{updated} updated")
        if skipped:
            parts.append(f"{skipped} skipped")
        self.report({"INFO"}, f"Sent {created + updated} objects ({', '.join(parts)})")
        return {"FINISHED"}


class SBOX_OT_ApplyMaterial(bpy.types.Operator):
    """Force-resync materials, UVs, and geometry for selected mesh objects.
    Manual escape hatch when Blender's depsgraph silently misses a material
    or UV edit (which happens — slot reassignment, image swap, or material
    pointer changes don't always fire the right update flags). This bypasses
    the geometry-hash gate and always pushes."""
    bl_idname = "sbox.bridge_apply_material"
    bl_label = "Apply Material"
    bl_description = (
        "Force-resync materials and UVs for selected mesh objects, bypassing "
        "the change-detection hash. Use when an applied material isn't "
        "showing up in s&box despite syncing"
    )

    @classmethod
    def poll(cls, context):
        if not connection.is_connected():
            return False
        return any(o.type == "MESH" for o in context.selected_objects)

    def execute(self, context):
        synced = 0
        for obj in context.selected_objects:
            if obj.type != "MESH":
                continue
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if sync._should_skip_object(obj):
                continue
            bid = sync.get_bridge_id(obj)
            if not bid:
                continue
            # Invalidate stored hash so send_update_mesh can't gate this out.
            if "sbox_bridge_hash" in obj:
                del obj["sbox_bridge_hash"]
            if obj.data is not None and "sbox_bridge_hash" in obj.data:
                del obj.data["sbox_bridge_hash"]
            # Drop cached vmatPaths for this object's materials so the
            # bridge regenerates them from current Blender state instead of
            # reusing a stale pointer.
            if obj.data and obj.data.materials:
                for slot in obj.data.materials:
                    if slot:
                        sync._material_hash_cache.pop(slot.name, None)
            sync.send_update_mesh(obj)
            synced += 1
        if synced:
            self.report({"INFO"}, f"Force-synced materials on {synced} object(s)")
        else:
            self.report({"WARNING"}, "No bridged mesh objects in selection")
        return {"FINISHED"}


class SBOX_OT_RemoveFromScene(bpy.types.Operator):
    bl_idname = "sbox.bridge_remove_from_scene"
    bl_label = "Remove from Scene"
    bl_description = "Delete selected objects from s&box scene but keep them in Blender"

    @classmethod
    def poll(cls, context):
        if not connection.is_connected():
            return False
        for obj in context.selected_objects:
            if sync.get_bridge_id(obj):
                return True
        return False

    def execute(self, context):
        count = 0
        for obj in list(context.selected_objects):
            bid = sync.get_bridge_id(obj)
            if bid:
                sync.send_delete(bid)
                sync._strip_bridge_props(obj)
                count += 1
        self.report({"INFO"}, f"Removed {count} object(s) from s&box scene")
        return {"FINISHED"}


class SBOX_OT_ClearBridgeID(bpy.types.Operator):
    bl_idname = "sbox.bridge_clear_id"
    bl_label = "Clear Bridge ID"
    bl_description = "Strip bridge ID from selected objects so they can be re-synced as new"

    @classmethod
    def poll(cls, context):
        for obj in context.selected_objects:
            if sync.get_bridge_id(obj):
                return True
        return False

    def execute(self, context):
        count = 0
        for obj in list(context.selected_objects):
            if sync.get_bridge_id(obj):
                sync._strip_bridge_props(obj)
                count += 1
        self.report({"INFO"}, f"Cleared bridge ID from {count} object(s)")
        return {"FINISHED"}


class SBOX_OT_SendChildren(bpy.types.Operator):
    bl_idname = "sbox.bridge_send_children"
    bl_label = "Send Children"
    bl_description = "Send all mesh children of the active collection to s&box"

    @classmethod
    def poll(cls, context):
        return connection.is_connected() and context.collection is not None

    def execute(self, context):
        col = context.collection
        if col == context.scene.collection:
            self.report({"WARNING"}, "Select a specific collection, not Scene Collection")
            return {"CANCELLED"}

        count = 0
        for obj in col.all_objects:
            if obj.type == "MESH" and not obj.get("sbox_scene_id") and not obj.get("sbox_type"):
                if sync._should_skip_object(obj):
                    continue
                if sync.get_bridge_id(obj):
                    sync.send_update_mesh(obj)
                else:
                    sync.send_create(obj)
                count += 1
            elif obj.type == "LIGHT" and not obj.get("sbox_scene_id"):
                if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                    if sync.get_bridge_id(obj):
                        sync.send_update_light(obj)
                    else:
                        sync.send_create_light(obj)
                    count += 1

        self.report({"INFO"}, f"Sent {count} objects from '{col.name}'")
        return {"FINISHED"}


class SBOX_OT_SelectBridgeObject(bpy.types.Operator):
    bl_idname = "sbox.bridge_select_object"
    bl_label = "Select"
    bl_description = "Select this object in the viewport"

    obj_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.obj_name)
        if obj:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
        return {"FINISHED"}


class SBOX_OT_ConfirmPendingDeletes(bpy.types.Operator):
    bl_idname = "sbox.bridge_confirm_deletes"
    bl_label = "Confirm Deletes"
    bl_description = "Immediately confirm all pending deletions"

    @classmethod
    def poll(cls, context):
        return connection.is_connected() and sync.get_pending_deletes()

    def execute(self, context):
        pending = sync.get_pending_deletes()
        for bid, _ in pending:
            sync.send_delete(bid)
        sync._pending_deletes.clear()
        self.report({"INFO"}, f"Confirmed {len(pending)} deletions")
        return {"FINISHED"}


class SBOX_OT_CancelPendingDeletes(bpy.types.Operator):
    bl_idname = "sbox.bridge_cancel_deletes"
    bl_label = "Cancel Deletes"
    bl_description = "Cancel pending deletions (objects remain in s&box)"

    @classmethod
    def poll(cls, context):
        return bool(sync.get_pending_deletes())

    def execute(self, context):
        count = len(sync.get_pending_deletes())
        sync.cancel_pending_deletes()
        self.report({"INFO"}, f"Cancelled {count} pending deletions")
        return {"FINISHED"}


class SBOX_OT_ConfirmInboundDeletes(bpy.types.Operator):
    bl_idname = "sbox.bridge_confirm_inbound_deletes"
    bl_label = "Confirm s&box Deletes"
    bl_description = "Permanently delete the objects held in Bridge Trash"

    @classmethod
    def poll(cls, context):
        return bool(sync.get_inbound_pending_deletes())

    def execute(self, context):
        n = sync.confirm_inbound_deletes()
        self.report({"INFO"}, f"Deleted {n} object(s)")
        return {"FINISHED"}


class SBOX_OT_RestoreInboundDeletes(bpy.types.Operator):
    bl_idname = "sbox.bridge_restore_inbound_deletes"
    bl_label = "Restore"
    bl_description = (
        "Bring the trashed objects back into the scene and re-send them "
        "to s&box under their original IDs"
    )

    @classmethod
    def poll(cls, context):
        return bool(sync.get_inbound_pending_deletes())

    def execute(self, context):
        n = sync.restore_inbound_deletes()
        self.report({"INFO"}, f"Restored {n} object(s)")
        return {"FINISHED"}


class SBOX_OT_ScalePreset(bpy.types.Operator):
    bl_idname = "sbox.bridge_scale_preset"
    bl_label = "Scale Preset"
    bl_description = (
        "Set scale factor AND grid together so one grid cell is always "
        "exactly 1 m — the visual grid never moves out from under existing work"
    )

    # Each preset sets scale_factor and grid_size to the SAME number, so the
    # overlay cell (grid_size / scale_factor) is exactly 1 m in every preset.
    # This is why 39.37 (true inches) is not offered: it's incommensurable
    # with a metric grid — the cell became 0.406 m, new snapped work stopped
    # landing on old module seams, and gaps appeared. 40 is 1.6% off true
    # inches and keeps the grid exact.
    preset: bpy.props.EnumProperty(items=[
        ('METRIC40', "40 — recommended",
         "1 m = 40 units, grid cell stays exactly 1 m. Near-real scale "
         "(1.6% off true inches): a 2 m wall is 80 units next to the "
         "72-unit player. Keep modeling on the same 1 m grid you started on"),
        ('GRID32', "32",
         "1 m = 32 units, grid cell stays 1 m. ~19% smaller than real: a "
         "2 m opening (64u) is too short for the 72u player — build "
         "doorways 2.5 m+ at this scale"),
        ('CLASSIC16', "16",
         "1 m = 16 units, grid cell stays 1 m. Half-scale world: a 2 m "
         "wall is 32 units, waist-high next to the player"),
    ])

    def execute(self, context):
        values = {'METRIC40': 40, 'GRID32': 32, 'CLASSIC16': 16}
        v = values[self.preset]
        s = context.scene.sbox_bridge
        # Grid first, then scale — both updates push to the engine and the
        # overlay lands on v/v = exactly 1 m per cell.
        s.grid_size = v
        s.scale_factor = float(v)
        self.report({"INFO"},
                    f"Scale {v} u/m, grid {v} (1 m cells) — bridged objects will resync")
        return {"FINISHED"}


class SBOX_OT_AlignSnap(bpy.types.Operator):
    bl_idname = "sbox.bridge_align_snap"
    bl_label = "Align Snapping"
    bl_description = (
        "Configure Blender's snapping to the bridge grid: absolute grid "
        "snap matching the viewport overlay (grid_size / scale_factor per cell)"
    )

    def execute(self, context):
        ts = context.scene.tool_settings
        ts.use_snap = True
        # Blender 4+ has 'GRID' (absolute) as its own snap element; older
        # builds spell it 'INCREMENT' + use_snap_grid_absolute.
        try:
            ts.snap_elements = {'GRID'}
        except Exception:
            ts.snap_elements = {'INCREMENT'}
            try:
                ts.use_snap_grid_absolute = True
            except Exception:
                pass
        s = context.scene.sbox_bridge
        cell = s.grid_size / max(s.scale_factor, 1e-6)
        self.report({"INFO"}, f"Snap aligned: {s.grid_size}u grid = {cell:.3f}m per cell")
        return {"FINISHED"}


class SBOX_OT_AddPlayerReference(bpy.types.Operator):
    bl_idname = "sbox.bridge_add_player_ref"
    bl_label = "Player Reference"
    bl_description = (
        "Add the Citizen model (non-synced, normalized to the 72-unit player "
        "height at the current scale factor) at the 3D cursor. Falls back to "
        "a 32 x 32 x 72 unit wireframe box if no Citizen FBX is found (set "
        "one under Sync > Citizen FBX)"
    )

    TEMPLATE_COLLECTION = "sbox_citizen_template"

    @staticmethod
    def resolve_citizen_fbx(settings):
        """First existing candidate: the user-set path, an FBX bundled in the
        addon's assets folder, or Documents/Blender/Citizen.fbx. None if no
        candidate exists (the operator then falls back to the wireframe box —
        s&box itself ships only compiled .vmdl_c, so there is nothing to
        auto-discover in the engine install)."""
        import os
        candidates = []
        user_path = (settings.citizen_fbx_path or "").strip()
        if user_path:
            candidates.append(bpy.path.abspath(user_path))
        candidates.append(os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "assets", "Citizen.fbx"))
        candidates.append(os.path.join(
            os.path.expanduser("~"), "Documents", "Blender", "Citizen.fbx"))
        for p in candidates:
            if p and os.path.isfile(p):
                return p
        return None

    def execute(self, context):
        import os

        s = context.scene.sbox_bridge
        sf = max(s.scale_factor, 1e-6)
        target_h = 72.0 / sf
        citizen_fbx = self.resolve_citizen_fbx(s)

        # Import the FBX at most ONCE, into an unlinked template collection.
        # The first version re-imported per click — the second copy's
        # duplicated armature/materials hard-crashed Blender's depsgraph
        # (null material in DepsgraphNodeBuilder::build_materials). Every
        # spawn is now a collection-instance empty sharing the one template:
        # no new meshes, no new materials, no armature duplication.
        template = bpy.data.collections.get(self.TEMPLATE_COLLECTION)
        if template is not None and not template.objects:
            template = None
        if template is None and citizen_fbx is not None:
            template = self._import_template(context, citizen_fbx)

        if template is not None:
            th = float(template.get("citizen_height", 0.0))
            f = (target_h / th) if th > 1e-6 else 1.0
            empty = bpy.data.objects.new("s&box Player Reference", None)
            empty.instance_type = 'COLLECTION'
            empty.instance_collection = template
            empty.empty_display_size = 0.1
            empty["sbox_bridge_ignore"] = True
            empty.scale = (f, f, f)
            empty.location = context.scene.cursor.location
            context.collection.objects.link(empty)
            self.report({"INFO"},
                        f"Citizen reference: {target_h:.2f}m tall at current scale")
            return {"FINISHED"}

        w = 32.0 / sf
        hx = w / 2.0
        verts = [(-hx, -hx, 0), (hx, -hx, 0), (hx, hx, 0), (-hx, hx, 0),
                 (-hx, -hx, target_h), (hx, -hx, target_h),
                 (hx, hx, target_h), (-hx, hx, target_h)]
        faces = [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1),
                 (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)]
        mesh = bpy.data.meshes.new("sbox_player_ref")
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        obj = bpy.data.objects.new("s&box Player (32x32x72u)", mesh)
        obj.display_type = 'WIRE'
        obj["sbox_bridge_ignore"] = True
        obj.location = context.scene.cursor.location
        context.collection.objects.link(obj)
        hint = "" if citizen_fbx else " (no Citizen FBX found — set one under Sync)"
        self.report({"INFO"},
                    f"Player reference: {w:.2f}m x {w:.2f}m x {target_h:.2f}m"
                    f" at current scale{hint}")
        return {"FINISHED"}

    def _import_template(self, context, citizen_fbx):
        """One-time FBX import into an UNLINKED collection. The collection is
        kept alive by the instance empties that reference it; if the user
        deletes every instance and saves, Blender purges it and the next
        click re-imports."""
        from mathutils import Vector
        try:
            before = set(bpy.data.objects)
            bpy.ops.import_scene.fbx(filepath=citizen_fbx)
            imported = [o for o in bpy.data.objects if o not in before]
            if not imported:
                return None

            zmin, zmax = 1e18, -1e18
            for o in imported:
                # Never synced — see _should_skip_object.
                o["sbox_bridge_ignore"] = True
                if o.type == 'MESH':
                    for corner in o.bound_box:
                        z = (o.matrix_world @ Vector(corner)).z
                        zmin = min(zmin, z)
                        zmax = max(zmax, z)

            col = bpy.data.collections.new(self.TEMPLATE_COLLECTION)
            for o in imported:
                for c in list(o.users_collection):
                    try:
                        c.objects.unlink(o)
                    except Exception:
                        pass
                col.objects.link(o)
            # Authored height (~0.72 m: s&box units at FBX cm scale) —
            # instances scale themselves to player height from this.
            col["citizen_height"] = max(zmax - zmin, 1e-6)
            return col
        except Exception as e:
            self.report({"WARNING"}, f"Citizen import failed ({e}) — using box")
            return None


class SBOX_OT_DeleteBridgeMaterial(bpy.types.Operator):
    bl_idname = "sbox.delete_bridge_material"
    bl_label = "Delete Material"
    bl_description = "Delete a generated bridge material (.vmat and textures)"

    material_name: bpy.props.StringProperty()

    def execute(self, context):
        import os
        settings = context.scene.sbox_bridge
        assets_path = bpy.path.abspath(settings.project_assets_path) if settings.project_assets_path else None

        if not assets_path or not os.path.isdir(assets_path):
            self.report({"ERROR"}, "Set Assets Path first")
            return {"CANCELLED"}

        bridge_dir = os.path.join(assets_path, "materials", "blender_bridge")
        if not os.path.isdir(bridge_dir):
            self.report({"WARNING"}, "No bridge materials found")
            return {"CANCELLED"}

        deleted = 0
        for f in os.listdir(bridge_dir):
            if f.startswith(self.material_name):
                try:
                    os.remove(os.path.join(bridge_dir, f))
                    deleted += 1
                except Exception:
                    pass

        self.report({"INFO"}, f"Deleted {deleted} file(s) for '{self.material_name}'")
        return {"FINISHED"}


class SBOX_OT_OpenBridgeMaterialFolder(bpy.types.Operator):
    bl_idname = "sbox.open_bridge_material_folder"
    bl_label = "Open Folder"
    bl_description = "Open the bridge materials folder"

    def execute(self, context):
        import os
        import subprocess
        settings = context.scene.sbox_bridge
        assets_path = bpy.path.abspath(settings.project_assets_path) if settings.project_assets_path else None

        if not assets_path:
            self.report({"ERROR"}, "Set Assets Path first")
            return {"CANCELLED"}

        bridge_dir = os.path.join(assets_path, "materials", "blender_bridge")
        if os.path.isdir(bridge_dir):
            subprocess.Popen(f'explorer "{bridge_dir}"')
        else:
            self.report({"WARNING"}, "Folder doesn't exist yet")
        return {"FINISHED"}


# ── Main Panel ───────────────────────────────────────────────────────────

class SBOX_PT_BridgePanel(bpy.types.Panel):
    bl_label = "s&box Bridge"
    bl_idname = "SBOX_PT_bridge_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "s&box"

    def draw(self, context):
        layout = self.layout
        is_live = connection.is_connected()
        is_recon = connection.is_reconnecting()

        # ── Sync Health (always the first row — the trust line) ───
        try:
            box = layout.box()
            row = box.row()
            if is_live:
                # Order matters: a degraded organ outranks a mute (the mute
                # might be a symptom), and both outrank the happy path.
                degraded = sync.get_degraded_reason()
                mute = sync.get_mute_reason()
                if degraded:
                    row.alert = True
                    row.label(text=f"DEGRADED: {degraded}", icon="ERROR")
                elif mute:
                    row.label(text=f"MUTED: {mute}", icon="PAUSE")
                else:
                    row.label(text="LIVE", icon="CHECKMARK")

                # Heartbeats, computed AT DRAW TIME — a dead timer can't
                # fake these; the ages just keep growing.
                sent_t, recv_t = connection.get_heartbeats()
                now = time.time()

                def _age(t):
                    if not t:
                        return "never"
                    d = now - t
                    if d < 10:
                        return f"{d:.1f}s"
                    if d < 60:
                        return f"{d:.0f}s"
                    return f"{d / 60:.0f}m"

                queued = len(sync._dirty_sends)
                sub = box.row()
                sub.scale_y = 0.8
                sub.label(
                    text=f"sent {_age(sent_t)} ago · recv {_age(recv_t)} ago"
                         f" · {queued} queued"
                )
            elif is_recon:
                row.alert = True
                attempt = connection.get_reconnect_attempt()
                row.label(
                    text=f"RECONNECTING (attempt {attempt})", icon="SORTTIME"
                )
            else:
                row.label(text="DISCONNECTED", icon="ERROR")

            settings = context.scene.sbox_bridge
            col = box.column(align=True)
            col.enabled = not is_live and not is_recon
            col.prop(settings, "host")
            col.prop(settings, "port")

            row = box.row()
            if is_live or is_recon:
                row.operator("sbox.bridge_disconnect", icon="CANCEL")
            else:
                row.operator("sbox.bridge_connect", icon="PLAY")
        except Exception as e:
            _draw_section_error(layout, "Connection", e)

        layout.separator()

        # ── Sync ──────────────────────────────────────────────────
        try:
            box = layout.box()
            box.label(text="Sync", icon="FILE_REFRESH")
            settings = context.scene.sbox_bridge
            box.prop(settings, "sync_mode")
            box.prop(settings, "auto_sync")
            box.prop(settings, "sync_on_connect")
            box.prop(settings, "scale_factor")
            sp = box.row(align=True)
            for pid, label, val in (('METRIC40', "40", 40.0),
                                    ('GRID32', "32", 32.0),
                                    ('CLASSIC16', "16", 16.0)):
                op = sp.operator("sbox.bridge_scale_preset", text=label,
                                 depress=(abs(settings.scale_factor - val) < 0.01))
                op.preset = pid
            sp.operator("sbox.bridge_align_snap", text="", icon='SNAP_GRID')
            sp.operator("sbox.bridge_add_player_ref", text="", icon='ARMATURE_DATA')
            row = box.row(align=True)
            row.label(text="Grid")
            row.prop(settings, "grid_size", text="")
            row.operator("sbox.bridge_halve_grid", text="", icon='REMOVE')
            row.operator("sbox.bridge_double_grid", text="", icon='ADD')
            presets = box.row(align=True)
            for v in (1, 2, 4, 8, 16, 32, 64, 128):
                op = presets.operator("sbox.bridge_set_grid_size", text=str(v),
                                      depress=(settings.grid_size == v))
                op.value = v
            box.prop(settings, "project_assets_path")
            # Only surface the Citizen FBX picker when nothing auto-resolves;
            # with a working candidate the button just works and the field is
            # clutter.
            if SBOX_OT_AddPlayerReference.resolve_citizen_fbx(settings) is None:
                box.prop(settings, "citizen_fbx_path")
            box.prop(settings, "auto_reconnect")

            row = box.row(align=True)
            row.operator("sbox.bridge_sync_all", icon="FILE_REFRESH")
            row.operator("sbox.bridge_force_resync", icon="RECOVER_LAST", text="Force Resync")

            if context.selected_objects:
                row = box.row(align=True)
                row.operator("sbox.bridge_send_to_scene", icon="EXPORT")
                row.operator("sbox.bridge_remove_from_scene", icon="REMOVE", text="")

                has_bid = any(sync.get_bridge_id(obj) for obj in context.selected_objects)
                if has_bid:
                    row = box.row(align=True)
                    row.operator("sbox.bridge_apply_material", icon="MATERIAL")
                    row.operator("sbox.bridge_clear_id", icon="TRASH", text="")

            # Send Children — active collection
            if context.collection and context.collection != context.scene.collection:
                row = box.row()
                row.operator("sbox.bridge_send_children", icon="OUTLINER_COLLECTION")
        except Exception as e:
            _draw_section_error(layout, "Sync", e)

        layout.separator()

        # ── Bridge Objects — problems first ───────────────────────
        # Panel real estate goes to what's BROKEN. Healthy objects collapse
        # into the summary line; only failed/modified/unsent get rows. The
        # old list spent 20 rows answering "what is fine?" — the only
        # question worth pixels is "what needs me?".
        try:
            box = layout.box()
            box.label(text="Bridge Objects", icon="OBJECT_DATA")

            STATUS_ICONS = {
                "unsent": "RADIOBUT_OFF",
                "synced": "CHECKMARK",
                "modified": "FILE_REFRESH",
                "received": "IMPORT",
                "failed": "CANCEL",
                "quarantined": "GHOST_ENABLED",
            }
            STATUS_NAMES = {
                "unsent": "Not Sent",
                "synced": "Synced",
                "modified": "Modified",
                "received": "Received",
                "failed": "Failed",
                "quarantined": "Quarantined",
            }
            PROBLEM_ORDER = ["failed", "modified", "unsent"]

            counts = {}
            problems = []

            for obj in bpy.data.objects:
                if obj.type not in ("MESH", "LIGHT"):
                    continue
                if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                    continue
                if sync._should_skip_object(obj):
                    continue

                status = sync.get_sync_status(obj)
                if not sync.get_bridge_id(obj):
                    status = "unsent"
                counts[status] = counts.get(status, 0) + 1
                if status in PROBLEM_ORDER:
                    problems.append((obj.name, status))

            parts = []
            for s in ["synced", "received", "modified", "unsent", "failed"]:
                if counts.get(s, 0) > 0:
                    parts.append(f"{counts[s]} {STATUS_NAMES[s].lower()}")
            box.label(text="  ".join(parts) if parts else "No bridge objects")

            problems.sort(key=lambda p: PROBLEM_ORDER.index(p[1]))
            for obj_name, status in problems[:20]:
                row = box.row(align=True)
                if status == "failed":
                    row.alert = True
                row.label(text=obj_name, icon=STATUS_ICONS.get(status, "QUESTION"))
                op = row.operator("sbox.bridge_select_object", text="",
                                  icon="RESTRICT_SELECT_OFF")
                op.obj_name = obj_name

            if len(problems) > 20:
                box.label(text=f"... and {len(problems) - 20} more")
        except Exception as e:
            _draw_section_error(layout, "Bridge Objects", e)

        # ── Info ──────────────────────────────────────────────────
        try:
            box = layout.box()
            box.label(text="Info", icon="INFO")
            mesh_count = sum(
                1 for obj in bpy.data.objects
                if obj.type == "MESH" and obj.get("sbox_bridge_id")
            )
            light_count = sum(
                1 for obj in bpy.data.objects
                if obj.type == "LIGHT" and obj.get("sbox_bridge_id")
            )
            box.label(text=f"Synced: {mesh_count} meshes, {light_count} lights")

            latency = connection.get_latency_ms()
            if latency > 0 and is_live:
                box.label(text=f"Latency: {latency:.0f}ms")

            if sync.is_play_mode():
                row = box.row()
                row.alert = True
                row.label(text="s&box Play Mode Active", icon="PLAY")
        except Exception as e:
            _draw_section_error(layout, "Info", e)

        # ── Pending Deletes ───────────────────────────────────────
        try:
            pending = sync.get_pending_deletes()
            if pending:
                layout.separator()
                box = layout.box()
                oldest = min(t for _, t in pending)
                remaining = max(0, sync.PENDING_DELETE_TIMEOUT - (time.time() - oldest))
                box.label(text=f"{len(pending)} pending deletion(s) ({remaining:.0f}s)", icon="TRASH")
                row = box.row(align=True)
                row.operator("sbox.bridge_confirm_deletes", icon="CHECKMARK")
                row.operator("sbox.bridge_cancel_deletes", icon="CANCEL")
        except Exception as e:
            _draw_section_error(layout, "Pending Deletes", e)

        # ── Bridge Trash (inbound s&box deletes, never auto-applied) ──
        try:
            trash = sync.get_inbound_pending_deletes()
            if trash:
                layout.separator()
                box = layout.box()
                row = box.row()
                row.alert = True
                row.label(text=f"s&box deleted {len(trash)} object(s)", icon="TRASH")
                for info in list(trash.values())[:5]:
                    r = box.row()
                    r.scale_y = 0.7
                    r.label(text=info.get("name", "?"), icon="DOT")
                if len(trash) > 5:
                    r = box.row()
                    r.scale_y = 0.7
                    r.label(text=f"...and {len(trash) - 5} more")
                box.label(text="Held in Bridge Trash — nothing deleted yet")
                row = box.row(align=True)
                row.operator("sbox.bridge_confirm_inbound_deletes",
                             text="Delete Here Too", icon="CHECKMARK")
                row.operator("sbox.bridge_restore_inbound_deletes",
                             text="Restore", icon="RECOVER_LAST")
        except Exception as e:
            _draw_section_error(layout, "Bridge Trash", e)

        # ── Warnings — auto-expire from panel, one-click clear ────
        # A warnings list that only ever grows trains the eye to ignore it.
        # Entries older than 2 minutes drop from the panel (they stay in the
        # activity log); the X dismisses everything now.
        try:
            now = time.time()
            warnings = [(t, m) for t, m in sync.get_warnings()
                        if now - t < 120.0]
            if warnings:
                layout.separator()
                box = layout.box()
                row = box.row()
                row.label(text="Warnings", icon="ERROR")
                row.operator("sbox.bridge_clear_warnings", text="", icon="X")
                for timestamp, msg in warnings[-5:]:
                    row = box.row()
                    row.alert = True
                    row.label(text=msg, icon="DOT")
        except Exception as e:
            _draw_section_error(layout, "Warnings", e)

        layout.separator()

        # ── Activity Log (collapsible) ───────────────────────────
        try:
            settings = context.scene.sbox_bridge
            box = layout.box()
            row = box.row()
            row.prop(settings, "show_activity_log",
                     icon="TRIA_DOWN" if settings.show_activity_log else "TRIA_RIGHT",
                     emboss=False)

            if settings.show_activity_log:
                log_entries = sync.get_activity_log()
                if log_entries:
                    import time as _time
                    now = _time.time()
                    for timestamp, msg in reversed(log_entries[-15:]):
                        elapsed = now - timestamp
                        if elapsed < 60:
                            time_str = f"{elapsed:.0f}s"
                        elif elapsed < 3600:
                            time_str = f"{elapsed / 60:.0f}m"
                        else:
                            time_str = f"{elapsed / 3600:.1f}h"
                        row = box.row()
                        row.scale_y = 0.7
                        row.label(text=f"[{time_str}] {msg}")
                else:
                    box.label(text="No activity yet")
        except Exception as e:
            _draw_section_error(layout, "Activity Log", e)

        layout.separator()

        # ── Materials ─────────────────────────────────────────────
        try:
            import os
            settings = context.scene.sbox_bridge
            assets_path = bpy.path.abspath(settings.project_assets_path) if settings.project_assets_path else None

            box = layout.box()
            row = box.row()
            row.label(text="Bridge Materials", icon="MATERIAL")
            row.operator("sbox.open_bridge_material_folder", text="", icon="FILE_FOLDER")

            if assets_path:
                bridge_dir = os.path.join(assets_path, "materials", "blender_bridge")
                if os.path.isdir(bridge_dir):
                    vmats = [f for f in os.listdir(bridge_dir) if f.endswith(".vmat")]
                    if vmats:
                        dir_files = os.listdir(bridge_dir)
                        for vmat in sorted(vmats):
                            mat_name = vmat[:-5]
                            row = box.row(align=True)
                            icon_id = None
                            for f in dir_files:
                                if f.startswith(mat_name + "_color."):
                                    icon_id = _material_preview_icon(
                                        os.path.join(bridge_dir, f))
                                    break
                            if icon_id:
                                row.label(text=mat_name, icon_value=icon_id)
                            else:
                                row.label(text=mat_name, icon="SHADING_RENDERED")
                            op = row.operator("sbox.delete_bridge_material", text="", icon="TRASH")
                            op.material_name = mat_name
                    else:
                        box.label(text="No materials generated yet")
                else:
                    box.label(text="No materials generated yet")
            else:
                box.label(text="Set Assets Path to manage materials")
        except Exception as e:
            _draw_section_error(layout, "Materials", e)
