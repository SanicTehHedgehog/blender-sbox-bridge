"""
N-panel UI for the s&box Bridge v2 addon.
Provides connect/disconnect, sync controls, grid, warnings, and material management.
"""

import bpy
import traceback
from . import connection
from . import sync


# ── Operators ─────────────────────────────────────────────────────────────

class SBOX_OT_Connect(bpy.types.Operator):
    bl_idname = "sbox.bridge_connect"
    bl_label = "Connect"
    bl_description = "Connect to the s&box bridge server"

    def execute(self, context):
        settings = context.scene.sbox_bridge
        success, session_id = connection.connect(
            host=settings.host,
            port=settings.port,
        )
        if success:
            settings.is_connected = True
            sync.start_timer()
            # Send unsynced Blender objects first, then request sync from s&box
            for obj in list(bpy.data.objects):
                if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                    continue
                if obj.type == "MESH" and not sync.get_bridge_id(obj):
                    sync.send_create(obj)
                elif obj.type == "LIGHT" and not sync.get_bridge_id(obj):
                    if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                        sync.send_create_light(obj)
            sync.send_sync()
            self.report({"INFO"}, f"Connected to s&box at {settings.host}:{settings.port}")
        else:
            settings.is_connected = False
            self.report({"ERROR"}, f"Failed to connect to {settings.host}:{settings.port}")
        return {"FINISHED"}


class SBOX_OT_Disconnect(bpy.types.Operator):
    bl_idname = "sbox.bridge_disconnect"
    bl_label = "Disconnect"
    bl_description = "Disconnect from the s&box bridge server"

    def execute(self, context):
        connection.disconnect()
        sync.stop_timer()
        context.scene.sbox_bridge.is_connected = False
        self.report({"INFO"}, "Disconnected from s&box")
        return {"FINISHED"}


class SBOX_OT_SyncAll(bpy.types.Operator):
    bl_idname = "sbox.bridge_sync_all"
    bl_label = "Sync All"
    bl_description = "Send all Blender objects to s&box and request s&box objects"

    @classmethod
    def poll(cls, context):
        return connection.is_connected()

    def execute(self, context):
        created = 0
        updated = 0
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if obj.type == "MESH":
                if not sync.get_bridge_id(obj):
                    sync.send_create(obj)
                    created += 1
                else:
                    sync.send_update_mesh(obj)
                    updated += 1
            elif obj.type == "LIGHT":
                if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                    if not sync.get_bridge_id(obj):
                        sync.send_create_light(obj)
                        created += 1
                    else:
                        sync.send_update_light(obj)
                        updated += 1
        sync.send_sync()
        self.report({"INFO"}, f"Synced {created + updated} objects ({created} new, {updated} updated)")
        return {"FINISHED"}


class SBOX_OT_ForceResync(bpy.types.Operator):
    bl_idname = "sbox.bridge_force_resync"
    bl_label = "Force Resync"
    bl_description = (
        "DESTRUCTIVE: deletes every bridge object on the s&box side and "
        "re-creates them from Blender. Any custom s&box-side materials "
        "(water shaders, manually-applied vmats) and any geometry edits "
        "made in s&box will be lost"
    )

    @classmethod
    def poll(cls, context):
        return connection.is_connected()

    def invoke(self, context, event):
        # Confirmation dialog. Force Resync is destructive — it deletes every
        # bridge object on the s&box side before re-creating, so any custom
        # materials or geometry authored in s&box are gone. Make the user
        # acknowledge before proceeding.
        return context.window_manager.invoke_confirm(
            self,
            event,
            message=(
                "Force Resync will DELETE every bridge object on the s&box side "
                "and re-create them from Blender.\n\n"
                "You will lose:\n"
                "  • Any custom materials applied in s&box (water shaders, "
                "manually-set vmats)\n"
                "  • Any geometry edits made in s&box on bridge objects\n"
                "  • All bridge object IDs (re-issued on recreate)\n\n"
                "Continue?"
            ),
            title="Force Resync — destructive",
            icon='ERROR',
            confirm_text="Force Resync",
        )

    def execute(self, context):
        # Step 1: Delete all existing bridge objects from s&box
        old_ids = []
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if obj.type in ("MESH", "LIGHT"):
                bid = sync.get_bridge_id(obj)
                if bid:
                    old_ids.append(bid)

        for bid in old_ids:
            sync.send_delete(bid)

        # Step 2: Strip all bridge properties from Blender objects
        count = 0
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if obj.type in ("MESH", "LIGHT"):
                for key in ["sbox_bridge_id", "sbox_bridge_name", "sbox_bridge_hash",
                             "sbox_bridge_status", "sbox_bridge_last_sync", "_remote_update_time"]:
                    if key in obj:
                        del obj[key]
                count += 1

        sync._last_known_bridge_ids.clear()
        sync._last_scale.clear()
        sync._last_write_seq.clear()
        sync._material_hash_cache.clear()
        sync._pending_deletes.clear()

        # Step 3: Re-create all objects with fresh IDs
        for obj in list(bpy.data.objects):
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                continue
            if sync._should_skip_object(obj):
                continue
            if obj.type == "MESH" and not sync.get_bridge_id(obj):
                sync.send_create(obj)
            elif obj.type == "LIGHT" and not sync.get_bridge_id(obj):
                if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                    sync.send_create_light(obj)

        # Don't call send_sync() — it would re-import old s&box objects as duplicates
        self.report({"INFO"}, f"Force resynced {count} objects")
        return {"FINISHED"}


class SBOX_OT_SendToScene(bpy.types.Operator):
    bl_idname = "sbox.bridge_send_to_scene"
    bl_label = "Send to Scene"
    bl_description = "Send selected objects to s&box (create new or update existing)"

    @classmethod
    def poll(cls, context):
        return connection.is_connected() and context.selected_objects

    def execute(self, context):
        created = 0
        updated = 0
        skipped = 0

        for obj in context.selected_objects:
            if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                skipped += 1
                continue

            if obj.type == "MESH":
                if sync.get_bridge_id(obj):
                    sync.send_update_mesh(obj)
                    updated += 1
                else:
                    sync.send_create(obj)
                    created += 1
            elif obj.type == "LIGHT":
                if obj.data and obj.data.type in sync.UNSUPPORTED_LIGHT_TYPES:
                    sync.add_warning(f"Skipped '{obj.name}': AREA lights not supported")
                    skipped += 1
                    continue
                if sync.get_bridge_id(obj):
                    sync.send_update_light(obj)
                    updated += 1
                else:
                    sync.send_create_light(obj)
                    created += 1
            else:
                skipped += 1

        parts = []
        if created:
            parts.append(f"{created} new")
        if updated:
            parts.append(f"{updated} updated")
        if skipped:
            parts.append(f"{skipped} skipped")
        self.report({"INFO"}, f"Sent {created + updated} objects ({', '.join(parts)})")
        return {"FINISHED"}


class SBOX_OT_RemoveFromScene(bpy.types.Operator):
    bl_idname = "sbox.bridge_remove_from_scene"
    bl_label = "Remove from Scene"
    bl_description = "Delete selected objects from s&box scene but keep them in Blender"

    @classmethod
    def poll(cls, context):
        if not connection.is_connected():
            return False
        for obj in context.selected_objects:
            if sync.get_bridge_id(obj):
                return True
        return False

    def execute(self, context):
        count = 0
        for obj in list(context.selected_objects):
            bid = sync.get_bridge_id(obj)
            if bid:
                sync.send_delete(bid)
                sync._strip_bridge_props(obj)
                count += 1
        self.report({"INFO"}, f"Removed {count} object(s) from s&box scene")
        return {"FINISHED"}


class SBOX_OT_ClearBridgeID(bpy.types.Operator):
    bl_idname = "sbox.bridge_clear_id"
    bl_label = "Clear Bridge ID"
    bl_description = "Strip bridge ID from selected objects so they can be re-synced as new"

    @classmethod
    def poll(cls, context):
        for obj in context.selected_objects:
            if sync.get_bridge_id(obj):
                return True
        return False

    def execute(self, context):
        count = 0
        for obj in list(context.selected_objects):
            if sync.get_bridge_id(obj):
                sync._strip_bridge_props(obj)
                count += 1
        self.report({"INFO"}, f"Cleared bridge ID from {count} object(s)")
        return {"FINISHED"}


class SBOX_OT_SendChildren(bpy.types.Operator):
    bl_idname = "sbox.bridge_send_children"
    bl_label = "Send Children"
    bl_description = "Send all mesh children of the active collection to s&box"

    @classmethod
    def poll(cls, context):
        return connection.is_connected() and context.collection is not None

    def execute(self, context):
        col = context.collection
        if col == context.scene.collection:
            self.report({"WARNING"}, "Select a specific collection, not Scene Collection")
            return {"CANCELLED"}

        count = 0
        for obj in col.all_objects:
            if obj.type == "MESH" and not obj.get("sbox_scene_id") and not obj.get("sbox_type"):
                if sync._should_skip_object(obj):
                    continue
                if sync.get_bridge_id(obj):
                    sync.send_update_mesh(obj)
                else:
                    sync.send_create(obj)
                count += 1
            elif obj.type == "LIGHT" and not obj.get("sbox_scene_id"):
                if obj.data and obj.data.type not in sync.UNSUPPORTED_LIGHT_TYPES:
                    if sync.get_bridge_id(obj):
                        sync.send_update_light(obj)
                    else:
                        sync.send_create_light(obj)
                    count += 1

        self.report({"INFO"}, f"Sent {count} objects from '{col.name}'")
        return {"FINISHED"}


class SBOX_OT_SelectBridgeObject(bpy.types.Operator):
    bl_idname = "sbox.bridge_select_object"
    bl_label = "Select"
    bl_description = "Select this object in the viewport"

    obj_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.obj_name)
        if obj:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
        return {"FINISHED"}


class SBOX_OT_ConfirmPendingDeletes(bpy.types.Operator):
    bl_idname = "sbox.bridge_confirm_deletes"
    bl_label = "Confirm Deletes"
    bl_description = "Immediately confirm all pending deletions"

    @classmethod
    def poll(cls, context):
        return connection.is_connected() and sync.get_pending_deletes()

    def execute(self, context):
        pending = sync.get_pending_deletes()
        for bid, _ in pending:
            sync.send_delete(bid)
        sync._pending_deletes.clear()
        self.report({"INFO"}, f"Confirmed {len(pending)} deletions")
        return {"FINISHED"}


class SBOX_OT_CancelPendingDeletes(bpy.types.Operator):
    bl_idname = "sbox.bridge_cancel_deletes"
    bl_label = "Cancel Deletes"
    bl_description = "Cancel pending deletions (objects remain in s&box)"

    @classmethod
    def poll(cls, context):
        return bool(sync.get_pending_deletes())

    def execute(self, context):
        count = len(sync.get_pending_deletes())
        sync.cancel_pending_deletes()
        self.report({"INFO"}, f"Cancelled {count} pending deletions")
        return {"FINISHED"}


class SBOX_OT_SetGrid(bpy.types.Operator):
    bl_idname = "sbox.set_grid"
    bl_label = "Set Grid"
    bl_description = "Set Blender grid to match s&box grid size"

    grid_size: bpy.props.IntProperty(name="Grid Size", default=16)

    def execute(self, context):
        try:
            _apply_sbox_grid(context, self.grid_size)
            self.report({"INFO"}, f"Grid set to {self.grid_size} units")
        except Exception as e:
            self.report({"WARNING"}, f"Grid error: {e}")
            traceback.print_exc()
        return {"FINISHED"}


class SBOX_OT_DeleteBridgeMaterial(bpy.types.Operator):
    bl_idname = "sbox.delete_bridge_material"
    bl_label = "Delete Material"
    bl_description = "Delete a generated bridge material (.vmat and textures)"

    material_name: bpy.props.StringProperty()

    def execute(self, context):
        import os
        settings = context.scene.sbox_bridge
        assets_path = bpy.path.abspath(settings.project_assets_path) if settings.project_assets_path else None

        if not assets_path or not os.path.isdir(assets_path):
            self.report({"ERROR"}, "Set Assets Path first")
            return {"CANCELLED"}

        bridge_dir = os.path.join(assets_path, "materials", "blender_bridge")
        if not os.path.isdir(bridge_dir):
            self.report({"WARNING"}, "No bridge materials found")
            return {"CANCELLED"}

        deleted = 0
        for f in os.listdir(bridge_dir):
            if f.startswith(self.material_name):
                try:
                    os.remove(os.path.join(bridge_dir, f))
                    deleted += 1
                except Exception:
                    pass

        self.report({"INFO"}, f"Deleted {deleted} file(s) for '{self.material_name}'")
        return {"FINISHED"}


class SBOX_OT_OpenBridgeMaterialFolder(bpy.types.Operator):
    bl_idname = "sbox.open_bridge_material_folder"
    bl_label = "Open Folder"
    bl_description = "Open the bridge materials folder"

    def execute(self, context):
        import os
        import subprocess
        settings = context.scene.sbox_bridge
        assets_path = bpy.path.abspath(settings.project_assets_path) if settings.project_assets_path else None

        if not assets_path:
            self.report({"ERROR"}, "Set Assets Path first")
            return {"CANCELLED"}

        bridge_dir = os.path.join(assets_path, "materials", "blender_bridge")
        if os.path.isdir(bridge_dir):
            subprocess.Popen(f'explorer "{bridge_dir}"')
        else:
            self.report({"WARNING"}, "Folder doesn't exist yet")
        return {"FINISHED"}


# ── Grid Helper ──────────────────────────────────────────────────────────

def _apply_sbox_grid(context, grid_size):
    """Set Blender grid to match s&box grid size."""
    try:
        sf = context.scene.sbox_bridge.scale_factor if hasattr(context.scene, "sbox_bridge") else 1.0
    except Exception:
        sf = 1.0
    inv_sf = 1.0 / sf if sf != 0 else 1.0

    try:
        context.scene.unit_settings.system = 'NONE'
        context.scene.unit_settings.scale_length = 1.0
    except Exception:
        pass

    try:
        context.scene.tool_settings.snap_elements = {'INCREMENT'}
        context.scene.tool_settings.use_snap = True
    except Exception:
        pass

    blender_grid = grid_size * inv_sf

    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    for space in area.spaces:
                        if space.type == 'VIEW_3D':
                            space.overlay.grid_scale = blender_grid
                            space.overlay.grid_subdivisions = 1
    except Exception:
        pass

    try:
        if hasattr(context.scene, "sbox_bridge"):
            context.scene.sbox_bridge.grid_size = grid_size
    except Exception:
        pass


# ── Main Panel ───────────────────────────────────────────────────────────

class SBOX_PT_BridgePanel(bpy.types.Panel):
    bl_label = "s&box Bridge"
    bl_idname = "SBOX_PT_bridge_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "s&box"

    def draw(self, context):
        layout = self.layout
        is_live = connection.is_connected()
        is_recon = connection.is_reconnecting()

        # ── Connection ────────────────────────────────────────────
        try:
            box = layout.box()
            row = box.row()
            if is_live:
                row.label(text="Status: Connected", icon="CHECKMARK")
            elif is_recon:
                attempt = connection.get_reconnect_attempt()
                row.label(text=f"Reconnecting... (attempt {attempt})", icon="SORTTIME")
            else:
                row.label(text="Status: Disconnected", icon="ERROR")

            settings = context.scene.sbox_bridge
            col = box.column(align=True)
            col.enabled = not is_live and not is_recon
            col.prop(settings, "host")
            col.prop(settings, "port")

            row = box.row()
            if is_live or is_recon:
                row.operator("sbox.bridge_disconnect", icon="CANCEL")
            else:
                row.operator("sbox.bridge_connect", icon="PLAY")
        except Exception:
            pass

        layout.separator()

        # ── Grid ──────────────────────────────────────────────────
        try:
            box = layout.box()
            box.label(text="Grid Size", icon="SNAP_GRID")
            row = box.row(align=True)
            for size in [2, 4, 8, 16, 32]:
                op = row.operator("sbox.set_grid", text=str(size))
                op.grid_size = size
            if hasattr(context.scene, "sbox_bridge"):
                box.label(text=f"s&box Grid: {context.scene.sbox_bridge.grid_size}")
        except Exception:
            pass

        layout.separator()

        # ── Sync ──────────────────────────────────────────────────
        try:
            box = layout.box()
            box.label(text="Sync", icon="FILE_REFRESH")
            settings = context.scene.sbox_bridge
            box.prop(settings, "sync_mode")
            box.prop(settings, "auto_sync")
            box.prop(settings, "scale_factor")
            box.prop(settings, "project_assets_path")
            box.prop(settings, "auto_reconnect")

            row = box.row(align=True)
            row.operator("sbox.bridge_sync_all", icon="FILE_REFRESH")
            row.operator("sbox.bridge_force_resync", icon="RECOVER_LAST", text="Force Resync")

            if context.selected_objects:
                row = box.row(align=True)
                row.operator("sbox.bridge_send_to_scene", icon="EXPORT")
                row.operator("sbox.bridge_remove_from_scene", icon="REMOVE", text="")

                has_bid = any(sync.get_bridge_id(obj) for obj in context.selected_objects)
                if has_bid:
                    row = box.row()
                    row.operator("sbox.bridge_clear_id", icon="TRASH")

            # Send Children — active collection
            if context.collection and context.collection != context.scene.collection:
                row = box.row()
                row.operator("sbox.bridge_send_children", icon="OUTLINER_COLLECTION")
        except Exception:
            pass

        layout.separator()

        # ── Bridge Objects (status indicators) ────────────────────
        try:
            box = layout.box()
            box.label(text="Bridge Objects", icon="OBJECT_DATA")

            STATUS_ICONS = {
                "unsent": "RADIOBUT_OFF",
                "synced": "CHECKMARK",
                "modified": "FILE_REFRESH",
                "received": "IMPORT",
            }
            STATUS_NAMES = {
                "unsent": "Not Sent",
                "synced": "Synced",
                "modified": "Modified",
                "received": "Received",
            }

            counts = {"unsent": 0, "synced": 0, "modified": 0, "received": 0}
            bridge_objs = []

            for obj in bpy.data.objects:
                if obj.type not in ("MESH", "LIGHT"):
                    continue
                if obj.get("sbox_scene_id") or obj.get("sbox_type"):
                    continue
                if sync._should_skip_object(obj):
                    continue

                status = sync.get_sync_status(obj)
                bid = sync.get_bridge_id(obj)
                if not bid:
                    status = "unsent"
                counts[status] = counts.get(status, 0) + 1
                bridge_objs.append((obj.name, status))

            # Summary row
            parts = []
            for s in ["synced", "modified", "unsent", "received"]:
                if counts[s] > 0:
                    parts.append(f"{counts[s]} {STATUS_NAMES[s].lower()}")
            if parts:
                box.label(text="  ".join(parts))

            # Object list (max 20 shown)
            import time as _time
            now = _time.time()
            for obj_name, status in bridge_objs[:20]:
                row = box.row(align=True)
                icon = STATUS_ICONS.get(status, "QUESTION")

                # Build label with relative time since last sync
                obj_ref = bpy.data.objects.get(obj_name)
                last_sync = obj_ref.get("sbox_bridge_last_sync", 0) if obj_ref else 0
                if last_sync > 0:
                    elapsed = now - last_sync
                    if elapsed < 60:
                        time_str = f"{elapsed:.0f}s ago"
                    elif elapsed < 3600:
                        time_str = f"{elapsed / 60:.0f}m ago"
                    else:
                        time_str = f"{elapsed / 3600:.1f}h ago"
                    row.label(text=f"{obj_name}  ({time_str})", icon=icon)
                else:
                    row.label(text=obj_name, icon=icon)

                op = row.operator("sbox.bridge_select_object", text="", icon="RESTRICT_SELECT_OFF")
                op.obj_name = obj_name

            if len(bridge_objs) > 20:
                box.label(text=f"... and {len(bridge_objs) - 20} more")
        except Exception:
            pass

        # ── Info ──────────────────────────────────────────────────
        try:
            box = layout.box()
            box.label(text="Info", icon="INFO")
            mesh_count = sum(
                1 for obj in bpy.data.objects
                if obj.type == "MESH" and obj.get("sbox_bridge_id")
            )
            light_count = sum(
                1 for obj in bpy.data.objects
                if obj.type == "LIGHT" and obj.get("sbox_bridge_id")
            )
            box.label(text=f"Synced: {mesh_count} meshes, {light_count} lights")

            latency = connection.get_latency_ms()
            if latency > 0 and is_live:
                box.label(text=f"Latency: {latency:.0f}ms")

            if sync.is_play_mode():
                row = box.row()
                row.alert = True
                row.label(text="s&box Play Mode Active", icon="PLAY")
        except Exception:
            pass

        # ── Pending Deletes ───────────────────────────────────────
        try:
            pending = sync.get_pending_deletes()
            if pending:
                layout.separator()
                box = layout.box()
                import time
                oldest = min(t for _, t in pending)
                remaining = max(0, sync.PENDING_DELETE_TIMEOUT - (time.time() - oldest))
                box.label(text=f"{len(pending)} pending deletion(s) ({remaining:.0f}s)", icon="TRASH")
                row = box.row(align=True)
                row.operator("sbox.bridge_confirm_deletes", icon="CHECKMARK")
                row.operator("sbox.bridge_cancel_deletes", icon="CANCEL")
        except Exception:
            pass

        # ── Warnings ──────────────────────────────────────────────
        try:
            warnings = sync.get_warnings()
            if warnings:
                layout.separator()
                box = layout.box()
                box.label(text="Warnings", icon="ERROR")
                for timestamp, msg in warnings[-5:]:
                    row = box.row()
                    row.alert = True
                    row.label(text=msg, icon="DOT")
        except Exception:
            pass

        layout.separator()

        # ── Activity Log (collapsible) ───────────────────────────
        try:
            settings = context.scene.sbox_bridge
            box = layout.box()
            row = box.row()
            row.prop(settings, "show_activity_log",
                     icon="TRIA_DOWN" if settings.show_activity_log else "TRIA_RIGHT",
                     emboss=False)

            if settings.show_activity_log:
                log_entries = sync.get_activity_log()
                if log_entries:
                    import time as _time
                    now = _time.time()
                    for timestamp, msg in reversed(log_entries[-15:]):
                        elapsed = now - timestamp
                        if elapsed < 60:
                            time_str = f"{elapsed:.0f}s"
                        elif elapsed < 3600:
                            time_str = f"{elapsed / 60:.0f}m"
                        else:
                            time_str = f"{elapsed / 3600:.1f}h"
                        row = box.row()
                        row.scale_y = 0.7
                        row.label(text=f"[{time_str}] {msg}")
                else:
                    box.label(text="No activity yet")
        except Exception:
            pass

        layout.separator()

        # ── Materials ─────────────────────────────────────────────
        try:
            import os
            settings = context.scene.sbox_bridge
            assets_path = bpy.path.abspath(settings.project_assets_path) if settings.project_assets_path else None

            box = layout.box()
            row = box.row()
            row.label(text="Bridge Materials", icon="MATERIAL")
            row.operator("sbox.open_bridge_material_folder", text="", icon="FILE_FOLDER")

            if assets_path:
                bridge_dir = os.path.join(assets_path, "materials", "blender_bridge")
                if os.path.isdir(bridge_dir):
                    vmats = [f for f in os.listdir(bridge_dir) if f.endswith(".vmat")]
                    if vmats:
                        for vmat in sorted(vmats):
                            mat_name = vmat[:-5]
                            row = box.row(align=True)
                            row.label(text=mat_name, icon="SHADING_RENDERED")
                            op = row.operator("sbox.delete_bridge_material", text="", icon="TRASH")
                            op.material_name = mat_name
                    else:
                        box.label(text="No materials generated yet")
                else:
                    box.label(text="No materials generated yet")
            else:
                box.label(text="Set Assets Path to manage materials")
        except Exception:
            pass
